package data.scripts.plugins;

import data.scripts.plugins.CharacterCreationPluginImpl;
import starsector.mod.pld.camp.PLDCampaignPlugin;

public class PLDCharacterCreationPluginImpl extends 
CharacterCreationPluginImpl
//PLDCharacterCreationPlugin
{}